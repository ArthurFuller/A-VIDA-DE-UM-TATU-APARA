using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

internal static class SertaoButtonHoverPalette
{
    internal static Color Ivory(float alpha) => new Color(1f, 253f / 255f, 245f / 255f, alpha);

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void Register()
    {
        SceneManager.sceneLoaded -= ApplyToScene;
        SceneManager.sceneLoaded += ApplyToScene;
    }

    private static void ApplyToScene(Scene scene, LoadSceneMode mode)
    {
        foreach (GameObject root in scene.GetRootGameObjects())
            foreach (Button button in root.GetComponentsInChildren<Button>(true))
                Apply(button);
    }

    internal static void Apply(Button button)
    {
        if (button.transition != Selectable.Transition.ColorTint) return;

        ColorBlock colors = button.colors;
        Color highlight = colors.highlightedColor;
        if (highlight.r - highlight.b < 0.10f || highlight.g - highlight.b < 0.07f ||
            Mathf.Abs(highlight.r - highlight.g) > 0.26f) return;

        colors.highlightedColor = Ivory(highlight.a);
        button.colors = colors;
    }
}
