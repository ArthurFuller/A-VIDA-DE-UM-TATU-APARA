using DG.Tweening;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[RequireComponent(typeof(Button))]
public sealed class HoverPunchButton : MonoBehaviour, IPointerEnterHandler,
    IPointerExitHandler, IPointerDownHandler, IPointerClickHandler
{
    [SerializeField, Min(1f)] private float hoverScale = 1.08f;
    [SerializeField, Range(0.5f, 1f)] private float pressedScale = 0.9f;
    [SerializeField, Min(0.05f)] private float duration = 0.16f;

    private Button button;
    private Image image;
    private Outline outline;
    private RectTransform rect;
    private Vector3 originalScale;
    private Vector2 originalPosition;
    private Quaternion originalRotation;
    private Color originalColor;
    private Color hoverColor;
    private bool hovered;
    private bool pressedEligible;
    private bool animating;
    public bool IsAnimating => animating;
    public bool AnimatePointerClick { get; set; } = true;

    private void Awake()
    {
        button = GetComponent<Button>();
        SertaoButtonHoverPalette.Apply(button);
        image = GetComponent<Image>();
        rect = (RectTransform)transform;
        originalScale = rect.localScale;
        originalPosition = rect.anchoredPosition;
        originalRotation = rect.localRotation;
        if (image != null)
        {
            originalColor = image.color;
            hoverColor = SertaoButtonHoverPalette.Ivory(originalColor.a);
        }
        outline = GetComponent<Outline>();
        if (outline == null) outline = gameObject.AddComponent<Outline>();
        outline.effectColor = SertaoButtonHoverPalette.Ivory(0.7f);
        outline.effectDistance = new Vector2(2f, -2f);
        outline.enabled = false;
    }

    private void OnDisable()
    {
        if (rect != null)
        {
            rect.DOKill();
            rect.localScale = originalScale;
            rect.anchoredPosition = originalPosition;
            rect.localRotation = originalRotation;
        }
        if (image != null)
        {
            image.DOKill();
            image.color = originalColor;
        }
        hovered = false;
        pressedEligible = false;
        animating = false;
        if (outline != null) outline.enabled = false;
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (button == null || !button.isActiveAndEnabled || !button.interactable) return;
        hovered = true;
        if (outline != null) outline.enabled = true;
        if (animating) return;
        rect.DOKill();
        rect.DOScale(originalScale * hoverScale, duration).SetEase(Ease.OutBack).SetUpdate(true);
        if (image != null)
            image.DOColor(hoverColor, duration).SetUpdate(true);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        hovered = false;
        if (outline != null) outline.enabled = false;
        if (animating) return;
        rect.DOKill();
        rect.DOScale(originalScale, duration).SetEase(Ease.OutCubic).SetUpdate(true);
        if (image != null) image.DOColor(originalColor, duration).SetUpdate(true);
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (!AnimatePointerClick || !pressedEligible || animating || button == null || !button.isActiveAndEnabled ||
            !button.interactable) return;
        PlayAcceptedClick();
    }

    public void PlayAcceptedClick()
    {
        if (rect == null || animating) return;
        pressedEligible = false;
        rect.DOKill();
        animating = true;
        DOTween.Sequence().SetTarget(rect).SetUpdate(true)
            .Append(rect.DOScale(originalScale * pressedScale, 0.08f))
            .Append(rect.DOScale(originalScale * (hovered ? hoverScale : 1f), duration)
                .SetEase(Ease.OutBack))
            .OnComplete(() =>
            {
                rect.localScale = originalScale * (hovered ? hoverScale : 1f);
                if (image != null) image.color = hovered ? hoverColor : originalColor;
                animating = false;
            })
            .OnKill(() => animating = false);
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        pressedEligible = AnimatePointerClick && !animating && button != null &&
            button.isActiveAndEnabled && button.interactable;
    }

    public void ShakeRejected()
    {
        if (rect == null || animating) return;
        AudioManager.Play(SoundCue.UiRejected);
        pressedEligible = false;
        rect.DOKill();
        animating = true;
        rect.localScale = originalScale * (hovered ? hoverScale : 1f);
        rect.anchoredPosition = originalPosition;
        rect.localRotation = originalRotation;
        rect.DOShakeRotation(0.32f, new Vector3(0f, 0f, 8f), 12, 90f).SetUpdate(true)
            .OnComplete(() =>
            {
                rect.localRotation = originalRotation;
                rect.localScale = originalScale * (hovered ? hoverScale : 1f);
                if (image != null) image.color = hovered ? hoverColor : originalColor;
                animating = false;
            })
            .OnKill(() =>
            {
                rect.localRotation = originalRotation;
                animating = false;
            });
    }
}
