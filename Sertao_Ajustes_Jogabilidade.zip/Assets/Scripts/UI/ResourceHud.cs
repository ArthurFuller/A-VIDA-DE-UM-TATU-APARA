using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

public enum ResourceKind { Wood, Fish, Corn, Pumpkin, Jerimum, Food, Coins, Milk, Eggs }

public sealed class ResourceHud : MonoBehaviour
{
    public sealed class DropBatch
    {
        internal readonly ResourceKind Kind;
        internal readonly List<RectTransform> Icons = new();
        internal bool Released;
        internal DropBatch(ResourceKind kind) { Kind = kind; }
    }

    [SerializeField] private ResourceBank resources;
    [SerializeField] private Text woodText;
    [SerializeField] private Text fishText;
    [SerializeField] private Text cassavaText;
    [SerializeField] private Text pumpkinText;
    [SerializeField] private Text cornText;
    [SerializeField] private Text foodText;
    [SerializeField] private Text coinText;
    [SerializeField] private Text animalText;
    [SerializeField] private Text eggText;
    [Header("Ícones em voo")]
    [SerializeField] private Sprite woodSprite;
    [SerializeField] private Sprite fishSprite;
    [SerializeField] private Sprite cornSprite;
    [SerializeField] private Sprite pumpkinSprite;
    [SerializeField] private Sprite jerimumSprite;
    [SerializeField] private Sprite foodSprite;
    [SerializeField] private Sprite coinSprite;
    [SerializeField] private Sprite milkSprite;
    [SerializeField] private Sprite eggSprite;
    [SerializeField, Min(0.1f), Tooltip("Duração da viagem de cada ícone até seu contador (segundos).")]
    private float flightDuration = 0.38f;
    [SerializeField, Min(0f), Tooltip("Intervalo mínimo entre chegadas de ícones do mesmo recurso (segundos). A animação do contador pode aumentar esse mínimo.")]
    private float iconInterval = 0.14f;
    [Header("Feedback do contador")]
    [SerializeField, Min(1f)] private float counterPulseScale = 1.08f;
    [SerializeField, Min(0.05f)] private float counterPulseDuration = 0.12f;
    [SerializeField, Min(0.05f)] private float counterFlashDuration = 0.11f;

    private readonly int[] inFlight = new int[9];
    // One arrival timeline per resource prevents overlapping gains from swallowing counter pulses.
    private readonly float[] lastScheduledArrival = new float[9];
    private Canvas canvas;
    private RectTransform canvasRect;
    private readonly int[] displayed = new int[9];
    private readonly Tween[] counterTweens = new Tween[9];
    private readonly Tween[] counterPulses = new Tween[9];
    private readonly Color[] textColors = new Color[9];
    private readonly Transform[] counterRoots = new Transform[9];
    private readonly Vector3[] counterRootScales = new Vector3[9];
    private readonly Color[] iconColors = new Color[9];
    private readonly bool[] missingSpriteWarnings = new bool[9];
    private readonly Stack<RectTransform> iconPool = new();
    private readonly HashSet<RectTransform> activeIcons = new();
    private const int MaxPooledIcons = 64;
    private readonly Material[] iconFlashMaterials = new Material[9];
    private readonly Material[] originalIconMaterials = new Material[9];
    private static readonly int FlashId = Shader.PropertyToID("_Flash");
    private static readonly int FlashColorId = Shader.PropertyToID("_FlashColor");
    private static readonly Color DebtColor = new Color(0.95f, 0.14f, 0.14f);
    private ResourceCounterHover counterHover;
    private TopBarAutoHide topBar;

    public bool HasFlyingResources
    {
        get
        {
            foreach (int amount in inFlight)
                if (amount > 0) return true;
            return false;
        }
    }

    private Camera UiCamera => canvas != null && canvas.renderMode != RenderMode.ScreenSpaceOverlay
        ? canvas.worldCamera : null;
    private float ArrivalInterval => Mathf.Max(iconInterval,
        counterPulseDuration, counterFlashDuration) + 0.01f;

    // Shared final-flight scheduler for regular gains and staged wood/fish drops.
    // Returns how long this icon waits BEFORE starting its trip to the counter.
    private float FlightWait(ResourceKind kind, float earliestDeparture)
    {
        int index = (int)kind;
        float now = Time.time;
        float travel = Mathf.Max(0.1f, flightDuration);
        float arrival = Mathf.Max(now + earliestDeparture + travel,
            lastScheduledArrival[index] + ArrivalInterval);
        lastScheduledArrival[index] = arrival;
        return Mathf.Max(earliestDeparture, arrival - now - travel);
    }

    private void Awake()
    {
        topBar = GetComponent<TopBarAutoHide>();
        canvas = GetComponentInParent<Canvas>();
        if (canvas != null) canvas = canvas.rootCanvas;
        if (canvas != null) canvasRect = canvas.transform as RectTransform;
    }

    private void OnEnable()
    {
        System.Array.Clear(lastScheduledArrival, 0, lastScheduledArrival.Length);
        counterHover = GetComponent<ResourceCounterHover>();
        Shader flashShader = Resources.Load<Shader>("ResourceIconFlash");
        for (int i = 0; i < displayed.Length; i++)
        {
            counterPulses[i]?.Kill();
            ResourceKind kind = (ResourceKind)i;
            displayed[i] = Stored(kind);
            Text label = TargetFor(kind);
            Graphic icon = counterHover != null ? counterHover.IconFor(kind) : null;
            if (label != null) textColors[i] = label.color;
            if (label != null && icon != null &&
                label.rectTransform.parent == icon.rectTransform.parent)
            {
                counterRoots[i] = label.rectTransform.parent;
                counterRootScales[i] = counterRoots[i].localScale;
            }
            if (icon != null)
            {
                iconColors[i] = icon.color;
                if (flashShader != null)
                {
                    originalIconMaterials[i] = icon.material;
                    iconFlashMaterials[i] = new Material(flashShader)
                        { hideFlags = HideFlags.DontSave };
                    icon.material = iconFlashMaterials[i];
                }
            }
        }
        if (resources != null) resources.Changed += Refresh;
        Refresh();
    }

    private void OnDisable()
    {
        if (resources != null) resources.Changed -= Refresh;
        DOTween.Kill(this);
        foreach (RectTransform rect in new List<RectTransform>(activeIcons))
            RecycleIcon(rect);
        for (int i = 0; i < displayed.Length; i++)
        {
            ResourceKind kind = (ResourceKind)i;
            Text label = TargetFor(kind);
            Graphic icon = counterHover != null ? counterHover.IconFor(kind) : null;
            if (label != null)
            {
                label.DOKill();
                label.color = textColors[i];
            }
            if (icon != null)
            {
                icon.DOKill();
                icon.color = iconColors[i];
            }
            if (iconFlashMaterials[i] != null)
            {
                if (icon != null) icon.material = originalIconMaterials[i];
                Destroy(iconFlashMaterials[i]);
                iconFlashMaterials[i] = null;
            }
            if (counterRoots[i] != null)
                counterRoots[i].localScale = counterRootScales[i];
        }
        System.Array.Clear(inFlight, 0, inFlight.Length);
    }

    private void OnDestroy()
    {
        while (iconPool.Count > 0)
        {
            RectTransform rect = iconPool.Pop();
            if (rect != null) Destroy(rect.gameObject);
        }
    }

    public void FlyFromWorld(ResourceKind kind, int amount, Vector3 origin,
        float pauseSeconds = 0f, System.Action onAllArrived = null,
        float appearanceDelay = 0f, float appearanceInterval = 0f, System.Action onEachAppearance = null)
    {
        Camera worldCamera = Camera.main;
        Vector2 screen = worldCamera != null ? (Vector2)worldCamera.WorldToScreenPoint(origin) :
            new Vector2(Screen.width * 0.5f, Screen.height * 0.5f);
        FlyFromScreen(kind, amount, screen, pauseSeconds, onAllArrived,
            appearanceDelay: appearanceDelay, appearanceInterval: appearanceInterval,
            onEachAppearance: onEachAppearance);
    }

    public void FlyFromRect(ResourceKind kind, int amount, RectTransform origin,
        System.Action onLastDeparture = null, int maxIcons = int.MaxValue, System.Action onAllArrived = null)
    {
        if (origin == null)
        {
            onLastDeparture?.Invoke();
            onAllArrived?.Invoke();
            return;
        }

        Vector2 screenOrigin = RectTransformUtility.WorldToScreenPoint(UiCamera,
            origin.TransformPoint(origin.rect.center));
        FlyFromScreen(kind, amount, screenOrigin, onAllArrived: onAllArrived,
            onLastDeparture: onLastDeparture, maxIcons: maxIcons);
    }

    public DropBatch CreateDropBatch(ResourceKind kind) => new DropBatch(kind);

    public void DropOne(DropBatch batch, Vector3 worldOrigin)
    {
        Camera worldCamera = Camera.main;
        Vector2 screen = worldCamera != null ?
            (Vector2)worldCamera.WorldToScreenPoint(worldOrigin) :
            new Vector2(Screen.width * 0.5f, Screen.height * 0.5f);
        DropOneAtScreen(batch, screen, null);
    }

    public void DropOneAtScreen(DropBatch batch, Vector2 screenOrigin, Vector2? screenLanding)
    {
        if (batch == null || batch.Released || canvasRect == null) return;
        Vector2 origin = CanvasPoint(screenOrigin);
        int index = batch.Icons.Count;
        RectTransform rect = GetIcon(batch.Kind);
        rect.sizeDelta = Vector2.one * FlightIconSize(batch.Kind, 34f);
        rect.anchoredPosition = origin;
        rect.localScale = Vector3.zero;
        batch.Icons.Add(rect);
        float angle = index * 2.39996f;
        Vector2 landing = screenLanding.HasValue
            ? CanvasPoint(screenLanding.Value) + new Vector2(Mathf.Cos(angle) * 16f,
                Mathf.Sin(angle) * 9f)
            : origin + new Vector2(Mathf.Cos(angle) * 18f,
                -35f + Mathf.Sin(angle) * 7f);
        rect.DOScale(1f, 0.2f).SetEase(Ease.OutBack).SetId(this);
        rect.DOAnchorPos(landing, screenLanding.HasValue ? 0.4f : 0.28f)
            .SetEase(screenLanding.HasValue ? Ease.OutCubic : Ease.OutBounce).SetId(this);
    }

    public void FlyDrops(DropBatch batch, System.Action onAllArrived = null)
    {
        if (batch == null || batch.Released || batch.Icons.Count == 0)
        {
            onAllArrived?.Invoke();
            return;
        }
        batch.Released = true;
        Text target = TargetFor(batch.Kind);
        if (target == null)
        {
            foreach (RectTransform icon in batch.Icons)
            {
                if (icon != null) icon.DOKill();
                RecycleIcon(icon);
            }
            onAllArrived?.Invoke();
            return;
        }
        int pending = batch.Icons.Count;
        inFlight[(int)batch.Kind] += pending;
        // Do not let a ResourceBank notification count these units before their icons land.
        counterTweens[(int)batch.Kind]?.Kill();
        counterTweens[(int)batch.Kind] = null;
        Refresh();
        topBar?.RevealForResources();
        for (int i = 0; i < batch.Icons.Count; i++)
        {
            RectTransform rect = batch.Icons[i];
            if (rect == null)
            {
                CreditArrival(batch.Kind, 1, false);
                if (--pending == 0) onAllArrived?.Invoke();
                continue;
            }
            rect.DOKill();
            Sequence flight = DOTween.Sequence().SetId(this);
            flight.AppendInterval(FlightWait(batch.Kind, 0f));
            flight.Append(FollowCounter(rect, target));
            flight.Join(rect.DOScale(0.4f, flightDuration).SetEase(Ease.InQuad));
            flight.OnComplete(() =>
            {
                CreditArrival(batch.Kind, 1);
                if (--pending == 0) onAllArrived?.Invoke();
            });
            flight.OnKill(() => RecycleIcon(rect));
        }
    }

    public void FlyFromScreen(ResourceKind kind, int amount, Vector2 screenOrigin,
        float pauseSeconds = 0f, System.Action onAllArrived = null, System.Action onLastDeparture = null,
        int maxIcons = int.MaxValue, float appearanceDelay = 0f,
        float appearanceInterval = 0f, System.Action onEachAppearance = null)
    {
        Text target = TargetFor(kind);
        if (amount <= 0 || canvasRect == null || !isActiveAndEnabled || target == null)
        {
            if (onEachAppearance != null)
                for (int i = 0; i < amount; i++)
                    DOVirtual.DelayedCall(appearanceDelay + i * appearanceInterval,
                        () => onEachAppearance(), false).SetLink(gameObject);
            onLastDeparture?.Invoke();
            onAllArrived?.Invoke();
            return;
        }
        inFlight[(int)kind] += amount;
        // A mudança no banco pode ter agendado a contagem antes de os ícones nascerem.
        counterTweens[(int)kind]?.Kill();
        counterTweens[(int)kind] = null;
        Refresh();
        if (topBar != null)
            pauseSeconds = Mathf.Max(pauseSeconds, topBar.PrepareResourceFeedback());
        Vector2 origin = CanvasPoint(screenOrigin);
        int count = Mathf.Min(amount, Mathf.Max(1, maxIcons));
        int pending = count;
        // Lotes grandes mantêm o voo curto. Cada ícone credita sua parte ao chegar.
        for (int i = 0; i < count; i++)
        {
            int credit = amount / count + (i < amount % count ? 1 : 0);
            CreateIcon(kind, i, count, origin, target, pauseSeconds, credit, () =>
                {
                    if (--pending == 0) onAllArrived?.Invoke();
                }, i == count - 1 ? onLastDeparture : null,
                appearanceDelay + i * appearanceInterval, onEachAppearance);
        }
    }

    private static float FlightIconSize(ResourceKind kind, float size) =>
        kind is ResourceKind.Coins or ResourceKind.Eggs ? size * 1.18f : size;

    private Vector2 CanvasPoint(Vector2 screen)
    {
        RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRect, screen, UiCamera,
            out Vector2 point);
        return point;
    }

    private Tween FollowCounter(RectTransform icon, Text target)
    {
        Vector2 start = icon.anchoredPosition;
        float progress = 0f;
        return DOTween.To(() => progress, value =>
        {
            progress = value;
            if (icon == null || target == null || canvasRect == null) return;
            Vector2 screen = RectTransformUtility.WorldToScreenPoint(UiCamera,
                target.rectTransform.TransformPoint(target.rectTransform.rect.center));
            icon.anchoredPosition = Vector2.LerpUnclamped(start, CanvasPoint(screen), value);
        }, 1f, flightDuration).SetEase(Ease.InCubic);
    }

    private void CreateIcon(ResourceKind kind, int index, int count, Vector2 origin,
        Text target, float pauseSeconds, int credit, System.Action onArrived, System.Action onDeparture,
        float appearanceDelay, System.Action onAppearance)
    {
        RectTransform rect = GetIcon(kind);
        rect.sizeDelta = Vector2.one * FlightIconSize(kind, 32f);
        float angle = index * 2.39996f;
        float radius = 4f + 11f * Mathf.Sqrt((index + 0.5f) / count);
        rect.anchoredPosition = origin + new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * radius;
        rect.localScale = Vector3.zero;
        const float appearDuration = 0.12f;
        appearanceDelay = Mathf.Max(0f, appearanceDelay);
        float flightWait = FlightWait(kind, appearanceDelay + appearDuration + Mathf.Max(0f, pauseSeconds));
        Sequence flight = DOTween.Sequence().SetId(this);
        if (appearanceDelay > 0f) flight.AppendInterval(appearanceDelay);
        if (onAppearance != null) flight.AppendCallback(() => onAppearance());
        flight.Append(rect.DOScale(1f, appearDuration).SetEase(Ease.OutBack));
        flight.AppendInterval(Mathf.Max(0f, flightWait - appearanceDelay - appearDuration));
        if (onDeparture != null) flight.AppendCallback(NotifyDeparture);
        flight.Append(FollowCounter(rect, target))
            .Join(rect.DOScale(0.4f, flightDuration).SetEase(Ease.InQuad))
            .OnComplete(() =>
            {
                CreditArrival(kind, credit);
                onArrived?.Invoke();
            })
            .OnKill(() =>
            {
                RecycleIcon(rect);
                NotifyDeparture();
            });

        void NotifyDeparture()
        {
            System.Action callback = onDeparture;
            onDeparture = null;
            callback?.Invoke();
        }
    }

    private RectTransform GetIcon(ResourceKind kind)
    {
        RectTransform rect = iconPool.Count > 0 ? iconPool.Pop() : null;
        if (rect == null)
            rect = (RectTransform)new GameObject("Recurso em voo", typeof(RectTransform),
                typeof(CanvasRenderer), typeof(Image)).transform;
        rect.SetParent(canvasRect, false);
        rect.gameObject.SetActive(true);
        activeIcons.Add(rect);
        rect.SetAsLastSibling();
        rect.anchorMin = rect.anchorMax = new Vector2(0.5f, 0.5f);
        Image image = rect.GetComponent<Image>();
        image.sprite = SpriteFor(kind);
        image.enabled = image.sprite != null;
        image.color = Color.white;
        image.preserveAspect = true;
        image.raycastTarget = false;
        return rect;
    }

    private void RecycleIcon(RectTransform rect)
    {
        if (rect == null || !activeIcons.Remove(rect)) return;
        rect.gameObject.SetActive(false);
        if (iconPool.Count < MaxPooledIcons) iconPool.Push(rect);
        else Destroy(rect.gameObject);
    }

    private Sprite SpriteFor(ResourceKind kind)
    {
        Sprite selected = kind switch
        {
            ResourceKind.Wood => woodSprite,
            ResourceKind.Fish => fishSprite,
            ResourceKind.Corn => cornSprite,
            ResourceKind.Pumpkin => pumpkinSprite,
            ResourceKind.Jerimum => jerimumSprite,
            ResourceKind.Food => foodSprite,
            ResourceKind.Coins => coinSprite,
            ResourceKind.Milk => milkSprite,
            ResourceKind.Eggs => eggSprite,
            _ => null
        };
        int index = (int)kind;
        if (selected == null && !missingSpriteWarnings[index])
        {
            missingSpriteWarnings[index] = true;
            Debug.LogWarning("Ícone em voo não configurado no ResourceHud: " + kind, this);
        }
        else if (selected != null) missingSpriteWarnings[index] = false;
        return selected;
    }

    private Text TargetFor(ResourceKind kind) => kind switch
    {
        ResourceKind.Wood => woodText,
        ResourceKind.Fish => fishText,
        ResourceKind.Corn => cornText,
        ResourceKind.Pumpkin => cassavaText,
        ResourceKind.Jerimum => pumpkinText,
        ResourceKind.Food => foodText,
        ResourceKind.Coins => coinText,
        ResourceKind.Eggs => eggText != null ? eggText : animalText,
        _ => animalText
    };

    private int Stored(ResourceKind kind) => resources == null ? 0 : kind switch
    {
        ResourceKind.Wood => resources.Wood,
        ResourceKind.Fish => resources.Fish,
        ResourceKind.Corn => resources.Corn,
        ResourceKind.Pumpkin => resources.Pumpkin,
        ResourceKind.Jerimum => resources.Jerimum,
        ResourceKind.Food => resources.Food,
        ResourceKind.Coins => resources.Coins,
        ResourceKind.Milk => resources.Milk,
        ResourceKind.Eggs => resources.Eggs,
        _ => 0
    };

    private int Shown(ResourceKind kind)
    {
        long value = (long)Stored(kind) - inFlight[(int)kind];
        return kind == ResourceKind.Coins ? (int)System.Math.Max(int.MinValue, value) :
            (int)System.Math.Max(0, value);
    }

    // The bank already owns the resource. Reveal each portion exactly when its icon lands.
    private void CreditArrival(ResourceKind kind, int amount, bool visibleFlight = true)
    {
        int index = (int)kind;
        inFlight[index] = Mathf.Max(0, inFlight[index] - amount);
        int next = (int)System.Math.Min(Shown(kind), (long)displayed[index] + amount);
        if (next > displayed[index])
        {
            displayed[index] = next;
            DrawCounter(kind);
            FlashCounter(kind, 1);
            if (visibleFlight) AudioManager.Play(kind switch
            {
                ResourceKind.Coins => SoundCue.CounterCoins,
                ResourceKind.Wood => SoundCue.CounterWood,
                ResourceKind.Fish => SoundCue.CounterFish,
                ResourceKind.Corn => SoundCue.CounterGrain,
                ResourceKind.Pumpkin or ResourceKind.Jerimum => SoundCue.CounterCrop,
                ResourceKind.Food => SoundCue.CounterFood,
                ResourceKind.Milk => SoundCue.CounterMilk,
                ResourceKind.Eggs => SoundCue.CounterEgg,
                _ => SoundCue.ResourceGained
            });
        }
        Refresh();
    }

    private void StepCounter(ResourceKind kind)
    {
        int index = (int)kind;
        int target = Shown(kind);
        if (displayed[index] == target) { counterTweens[index] = null; return; }
        int direction = target > displayed[index] ? 1 : -1;
        displayed[index] += direction;
        DrawCounter(kind);
        FlashCounter(kind, direction);
        counterTweens[index] = DOVirtual.DelayedCall(0.075f, () => StepCounter(kind), false)
            .SetTarget(this);
    }

    private void FlashCounter(ResourceKind kind, int direction)
    {
        int index = (int)kind;
        Color flash = direction < 0 ? DebtColor : Color.white;
        Color resting = kind == ResourceKind.Coins && displayed[index] < 0 ?
            DebtColor : textColors[index];
        Text label = TargetFor(kind);
        Graphic icon = counterHover != null ? counterHover.IconFor(kind) : null;
        float flashIn = counterFlashDuration * 0.32f;
        float flashOut = counterFlashDuration - flashIn;
        counterPulses[index]?.Kill();
        Sequence pulse = DOTween.Sequence().SetTarget(this);
        counterPulses[index] = pulse;
        if (counterRoots[index] != null)
        {
            counterRoots[index].localScale = counterRootScales[index];
            pulse.Insert(0f, counterRoots[index]
                .DOScale(counterRootScales[index] * counterPulseScale,
                    counterPulseDuration * 0.5f)
                .SetLoops(2, LoopType.Yoyo).SetEase(Ease.OutQuad));
        }
        if (label != null)
        {
            label.DOKill();
            label.color = resting;
            pulse.Insert(0f, label.DOColor(flash, flashIn));
            pulse.Insert(flashIn, label.DOColor(resting, flashOut));
        }
        if (icon != null)
        {
            icon.DOKill();
            icon.color = iconColors[index];
            Material material = iconFlashMaterials[index];
            if (material != null)
            {
                material.SetFloat(FlashId, 0f);
                material.SetColor(FlashColorId, flash);
                material.SetFloat(FlashId, 0f);
                pulse.Insert(0f, DOTween.To(() => material.GetFloat(FlashId),
                    value => material.SetFloat(FlashId, value), 1f, flashIn));
                pulse.Insert(flashIn, DOTween.To(() => material.GetFloat(FlashId),
                    value => material.SetFloat(FlashId, value), 0f, flashOut));
            }
            else
            {
                Color fallback = new Color(flash.r, flash.g, flash.b, iconColors[index].a);
                pulse.Insert(0f, icon.DOColor(fallback, flashIn));
                pulse.Insert(flashIn, icon.DOColor(iconColors[index], flashOut));
            }
        }
    }

    private void DrawCounter(ResourceKind kind)
    {
        Text label = TargetFor(kind);
        if (label == null) return;
        if (eggText == null && (kind == ResourceKind.Milk || kind == ResourceKind.Eggs))
            label.text = displayed[(int)ResourceKind.Milk] + "  Ovos: " +
                displayed[(int)ResourceKind.Eggs];
        else label.text = displayed[(int)kind].ToString();
        if (kind == ResourceKind.Coins && (counterPulses[(int)kind] == null ||
            !counterPulses[(int)kind].IsActive()))
            label.color = displayed[(int)kind] < 0 ? DebtColor : textColors[(int)kind];
    }

    private void Refresh()
    {
        if (resources == null) return;
        bool changed = false;
        for (int i = 0; i < displayed.Length; i++)
            if (displayed[i] != Shown((ResourceKind)i)) { changed = true; break; }

        // The bank updates immediately; only its visual counting waits for the HUD.
        float revealDelay = changed && topBar != null ? topBar.PrepareResourceFeedback() : 0f;
        float countDelay = Mathf.Max(0.075f, revealDelay + 0.05f);
        for (int i = 0; i < displayed.Length; i++)
        {
            ResourceKind kind = (ResourceKind)i;
            DrawCounter(kind);
            if (displayed[i] == Shown(kind)) continue;
            if (revealDelay > 0f) counterTweens[i]?.Kill();
            if (counterTweens[i] == null || !counterTweens[i].IsActive())
                counterTweens[i] = DOVirtual.DelayedCall(countDelay, () => StepCounter(kind), false)
                    .SetTarget(this);
        }
    }
}
